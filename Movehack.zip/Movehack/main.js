(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["main"],{

/***/ "./src/$$_lazy_route_resource lazy recursive":
/*!**********************************************************!*\
  !*** ./src/$$_lazy_route_resource lazy namespace object ***!
  \**********************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

function webpackEmptyAsyncContext(req) {
	// Here Promise.resolve().then() is used instead of new Promise() to prevent
	// uncaught exception popping up in devtools
	return Promise.resolve().then(function() {
		var e = new Error("Cannot find module '" + req + "'");
		e.code = 'MODULE_NOT_FOUND';
		throw e;
	});
}
webpackEmptyAsyncContext.keys = function() { return []; };
webpackEmptyAsyncContext.resolve = webpackEmptyAsyncContext;
module.exports = webpackEmptyAsyncContext;
webpackEmptyAsyncContext.id = "./src/$$_lazy_route_resource lazy recursive";

/***/ }),

/***/ "./src/app/QrCodeComponent/qr-code.component.css":
/*!*******************************************************!*\
  !*** ./src/app/QrCodeComponent/qr-code.component.css ***!
  \*******************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = ".imgclass > img {\n  width:200px !important;\n}\n\n.imgclass {\n  width:200px\n}"

/***/ }),

/***/ "./src/app/QrCodeComponent/qr-code.component.html":
/*!********************************************************!*\
  !*** ./src/app/QrCodeComponent/qr-code.component.html ***!
  \********************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<ngx-qrcode [qrc-element-type]=\"'img'\" [qrc-value] = \"data\"       qrc-class = \"imgclass\"   qrc-errorCorrectionLevel = \"L\">\n\n</ngx-qrcode>"

/***/ }),

/***/ "./src/app/QrCodeComponent/qr-code.component.ts":
/*!******************************************************!*\
  !*** ./src/app/QrCodeComponent/qr-code.component.ts ***!
  \******************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
var core_1 = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
var QrCodeComponent = /** @class */ (function () {
    function QrCodeComponent() {
    }
    __decorate([
        core_1.Input(),
        __metadata("design:type", Object)
    ], QrCodeComponent.prototype, "data", void 0);
    QrCodeComponent = __decorate([
        core_1.Component({
            selector: 'qr-code',
            template: __webpack_require__(/*! ./qr-code.component.html */ "./src/app/QrCodeComponent/qr-code.component.html"),
            styles: [__webpack_require__(/*! ./qr-code.component.css */ "./src/app/QrCodeComponent/qr-code.component.css")]
        })
    ], QrCodeComponent);
    return QrCodeComponent;
}());
exports.QrCodeComponent = QrCodeComponent;


/***/ }),

/***/ "./src/app/QrScannerComponent/qr-scanner.component.css":
/*!*************************************************************!*\
  !*** ./src/app/QrScannerComponent/qr-scanner.component.css ***!
  \*************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = ""

/***/ }),

/***/ "./src/app/QrScannerComponent/qr-scanner.component.html":
/*!**************************************************************!*\
  !*** ./src/app/QrScannerComponent/qr-scanner.component.html ***!
  \**************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "\n<div *ngIf=\"availableDevices\">\n    <div class=\"input-group mb-3\">\n            <div class=\"input-group-prepend\">\n                <label class=\"input-group-text\" for=\"inputGroupSelect01\">Choose Camera</label>\n            </div>\n            <select class=\"custom-select\" (change)=\"onDeviceSelectChange($event.target.value)\">\n                    <option value=\"\" [selected]=\"!selectedDevice\">No Device</option>\n                    <option *ngFor=\"let device of availableDevices\" [value]=\"device.deviceId\" [selected]=\"selectedDevice && device.deviceId === selectedDevice.deviceId\">{{ device.label }}</option>\n                </select>\n            </div>\n</div>\n<div [hidden]=\"!hasCameras\" class=\"test-class\" >\n    <zxing-scanner #scanner class=\"test-class\" start=\"true\" [device]=\"selectedDevice\" (scanSuccess)=\"handleQrCodeResult($event)\"></zxing-scanner>\n    <h2 *ngIf=\"!this.selectedDevice\">No camera selected.</h2>\n</div>\n<div *ngIf=\"!hasCameras && hasPermission === true\">\n<h1>Looks like your actual device does not has cameras, or I could no find'em. </h1>\n</div>\n<div *ngIf=\"hasPermission === undefined\">\n<h1>Waiting for permissions.</h1>\n<blockquote>\n    <h2>If your device does not has cameras, no permissions will be asked.</h2>\n</blockquote>\n</div>\n<div *ngIf=\"hasPermission === false\">\n<h1>You denied the camera permissions, we can't scan anything without it. 😪</h1>\n</div>"

/***/ }),

/***/ "./src/app/QrScannerComponent/qr-scanner.component.ts":
/*!************************************************************!*\
  !*** ./src/app/QrScannerComponent/qr-scanner.component.ts ***!
  \************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
var core_1 = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
var QrScannerComponent = /** @class */ (function () {
    function QrScannerComponent() {
        this.ngVersion = core_1.VERSION.full;
        this.hasCameras = false;
        this.vendorData = "758194450368";
        this.vendorType = "Bus";
        this.qrData = new core_1.EventEmitter();
    }
    QrScannerComponent.prototype.ngOnInit = function () {
        var _this = this;
        this.scanner.camerasFound.subscribe(function (devices) {
            _this.hasCameras = true;
            console.log('Devices: ', devices);
            _this.availableDevices = devices;
            // selects default camera 
            for (var _i = 0, devices_1 = devices; _i < devices_1.length; _i++) {
                var device = devices_1[_i];
                _this.scanner.changeDevice(device);
                _this.selectedDevice = device;
                break;
            }
        });
        this.scanner.camerasNotFound.subscribe(function (devices) {
            console.error('An error has occurred when trying to enumerate your video-stream-enabled devices.');
        });
        this.scanner.permissionResponse.subscribe(function (answer) {
            _this.hasPermission = answer;
        });
    };
    QrScannerComponent.prototype.handleQrCodeResult = function (resultString) {
        var _this = this;
        console.log('Result: ', resultString);
        this.qrResultString = resultString;
        var promise = new Promise(function (resolve, reject) {
            if ("geolocation" in navigator) {
                navigator.geolocation.getCurrentPosition(function (position) {
                    resolve(position);
                });
            }
        });
        Promise.resolve(promise).then(function (position) {
            var qrDataToSend = {
                "customerAadhaar": _this.qrResultString,
                "location": position
            };
            _this.qrData.emit(qrDataToSend);
        });
    };
    QrScannerComponent.prototype.onDeviceSelectChange = function (selectedValue) {
        console.log('Selection changed: ', selectedValue);
        this.selectedDevice = this.scanner.getDeviceById(selectedValue);
    };
    __decorate([
        core_1.ViewChild('scanner'),
        __metadata("design:type", Object)
    ], QrScannerComponent.prototype, "scanner", void 0);
    __decorate([
        core_1.Input(),
        __metadata("design:type", Object)
    ], QrScannerComponent.prototype, "vendorData", void 0);
    __decorate([
        core_1.Input(),
        __metadata("design:type", Object)
    ], QrScannerComponent.prototype, "vendorType", void 0);
    __decorate([
        core_1.Output(),
        __metadata("design:type", Object)
    ], QrScannerComponent.prototype, "qrData", void 0);
    QrScannerComponent = __decorate([
        core_1.Component({
            selector: 'qr-scanner',
            template: __webpack_require__(/*! ./qr-scanner.component.html */ "./src/app/QrScannerComponent/qr-scanner.component.html"),
            styles: [__webpack_require__(/*! ./qr-scanner.component.css */ "./src/app/QrScannerComponent/qr-scanner.component.css")]
        })
    ], QrScannerComponent);
    return QrScannerComponent;
}());
exports.QrScannerComponent = QrScannerComponent;


/***/ }),

/***/ "./src/app/SessionManager/session-manager.service.ts":
/*!***********************************************************!*\
  !*** ./src/app/SessionManager/session-manager.service.ts ***!
  \***********************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
Object.defineProperty(exports, "__esModule", { value: true });
var core_1 = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
var ngx_webstorage_service_1 = __webpack_require__(/*! ngx-webstorage-service */ "./node_modules/ngx-webstorage-service/esm5/ngx-webstorage-service.js");
var http_1 = __webpack_require__(/*! @angular/common/http */ "./node_modules/@angular/common/fesm5/http.js");
var UserDetails_1 = __webpack_require__(/*! ../user-transaction/UserDetails */ "./src/app/user-transaction/UserDetails.ts");
var service_service_1 = __webpack_require__(/*! ../service/service.service */ "./src/app/service/service.service.ts");
var SessionManagerService = /** @class */ (function () {
    function SessionManagerService(storage, http, service) {
        this.storage = storage;
        this.http = http;
        this.service = service;
        this.baseUri = "http://ec2-13-232-98-71.ap-south-1.compute.amazonaws.com/parse/";
    }
    SessionManagerService.prototype.setUserSession = function (sessionToken) {
        this.storage.set('userSessionToken', sessionToken);
    };
    SessionManagerService.prototype.getGetUserDetails = function (sessionToken) {
        var _this = this;
        var httpOptions = {
            headers: new http_1.HttpHeaders({
                "X-Parse-Application-Id": "myAppId",
                "Content-Type": "application/json",
                "X-Parse-REST-API-Key": "myRestKey"
            })
        };
        var post_body = {
            "sessionToken": sessionToken
        };
        return this.http.post(this.baseUri + "functions/getUserData", post_body, httpOptions)
            .toPromise()
            .then(function (res) {
            console.log("Service called for user object ", res.result);
            _this.service.setUserObject(res.result);
            return res;
        })
            .catch(this.handleError);
    };
    SessionManagerService.prototype.getUserSessionToken = function () {
        return this.storage.get('userSessionToken');
    };
    SessionManagerService.prototype.getCloudUserName = function (sessionToken) {
        var httpOptions = {
            headers: new http_1.HttpHeaders({
                "X-Parse-Application-Id": "myAppId",
                "Content-Type": "application/json",
                "X-Parse-REST-API-Key": "myRestKey"
            })
        };
        var post_body = {
            "sessionToken": sessionToken
        };
        return this.http.post(this.baseUri + "functions/getUserName", post_body, httpOptions)
            .toPromise()
            .then(function (res) { return res; })
            .catch(this.handleError);
    };
    SessionManagerService.prototype.getUserName = function () {
        return this.storage.get('userName');
    };
    SessionManagerService.prototype.getUserSessionAadhaarNo = function () {
        return this.storage.get('userAadhaarNo');
    };
    /*
    Set & get
    */
    SessionManagerService.prototype.setUserFirstName = function (firstName) {
        this.storage.set('userFirstName', firstName);
    };
    SessionManagerService.prototype.getUserFirstName = function () {
        return this.storage.get('userFirstName');
    };
    SessionManagerService.prototype.setUserLastName = function (lastName) {
        this.storage.set('userLastName', lastName);
    };
    SessionManagerService.prototype.getUserLastName = function () {
        return this.storage.get('userLastName');
    };
    SessionManagerService.prototype.setUserMobile = function (mobile) {
        this.storage.set('mobile', mobile);
    };
    SessionManagerService.prototype.getMobile = function () {
        return this.storage.get('mobile');
    };
    SessionManagerService.prototype.setEmail = function (email) {
        this.storage.set('email', email);
    };
    SessionManagerService.prototype.getEmail = function () {
        return this.storage.get('email');
    };
    SessionManagerService.prototype.setUserType = function (userType) {
        this.storage.set('userType', userType);
    };
    SessionManagerService.prototype.getUserType = function () {
        return this.storage.get('userType');
    };
    SessionManagerService.prototype.setVendorType = function (vendorType) {
        this.storage.set('vendorType', vendorType);
    };
    SessionManagerService.prototype.getVendorType = function () {
        return this.storage.get('vendorType');
    };
    SessionManagerService.prototype.setAdhar = function (adhaar) {
        this.storage.set('adhaar', adhaar);
    };
    SessionManagerService.prototype.getAadhaar = function () {
        return this.storage.get('adhaar');
    };
    SessionManagerService.prototype.unsetUserSession = function () {
        this.storage.remove('userSessionToken');
        this.storage.remove('userAadhaarNo');
        this.storage.remove('vendorType');
        this.storage.remove('adhaar');
        this.storage.remove('userType');
        this.storage.remove('email');
        this.storage.remove('mobile');
        this.storage.remove('userLastName');
        this.storage.remove('userFirstName');
        this.service.setUserObject(new UserDetails_1.User("", "", "", "", "", "", ""));
    };
    SessionManagerService.prototype.handleError = function (error) {
        console.log('Error From Service: ' + error);
        return Promise.reject(error.message || error);
    };
    SessionManagerService = __decorate([
        core_1.Injectable({
            providedIn: 'root'
        }),
        __param(0, core_1.Inject(ngx_webstorage_service_1.SESSION_STORAGE)),
        __metadata("design:paramtypes", [Object, http_1.HttpClient,
            service_service_1.ServiceService])
    ], SessionManagerService);
    return SessionManagerService;
}());
exports.SessionManagerService = SessionManagerService;


/***/ }),

/***/ "./src/app/SignUpComponent/signup.component.html":
/*!*******************************************************!*\
  !*** ./src/app/SignUpComponent/signup.component.html ***!
  \*******************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<div class=\"col-md-12 col-lg-12 col-xs-12 col-sm-12\" *ngIf=\"!moveToAuth\" style=\"background-image: url('../../assets/background/METRO.jpg'); height: 100%;\n\n/* Center and scale the image nicely */\nbackground-position: center;\nbackground-repeat: no-repeat;\nbackground-size: cover;   min-height:800px\">\n  <div class=\"col-4 offset-4\" style=\"padding-bottom: 30px\">\n    <div class=\"row justify-content-center\">\n      <div class=\"card\" style=\"margin-top: 8%\">\n        <div class=\"card-body\">\n          <img src=\"../../assets/background/adhar.png\" style=\"width:150px;height: 100px;\"/>\n        </div>\n      </div>\n    </div>\n    <div class=\"card card-primary card-inverse\" style=\"margin-top:8%\">\n      <div class=\"card-header\" style=\"color: #fff;background-color: #094162;border-color: #2e6da4;\">\n        <h5 align=\"center\">Register</h5>\n      </div>\n      <div class=\"card-body\">\n        <div class=\"form\">\n          <div class=\"input-group\" style=\"margin-top:10px; margin-bottom:10px\">\n            <div class=\"input-group-prepend\">\n              <span class=\"input-group-text\" id=\"aadhaar\" style=\"width: 100px\">Aadhaar</span>\n            </div>\n            <input type=\"number\" class=\"form-control\" aria-describedby=\"inputGroupPrepend\" id=\"aadharId\"\n                   placeholder=\" XXXX-XXXX-XXXX \"\n                   #sourc=\"ngModel\" name=\"aadharId\" [(ngModel)]=\"aadhar\" minlength=\"12\" maxlength=\"12\" required>\n          </div>\n          <div class=\"input-group\" style=\"margin-top:10px; margin-bottom:10px\">\n            <div class=\"input-group-prepend\">\n              <span class=\"input-group-text\" id=\"Mobile\" style=\"width: 100px\">Mobile</span>\n            </div>\n            <input type=\"number\" class=\"form-control\" aria-describedby=\"inputGroupPrepend\" placeholder=\" 999999999 \"\n                   id=\"phoneNo\" name=\"phoneNo\"\n                   name=\"phoneNo\" [(ngModel)]=\"phoneNo\" required>\n          </div>\n          <div class=\"input-group\" style=\"margin-top:10px; margin-bottom:10px\">\n            <div class=\"input-group-prepend\">\n              <span class=\"input-group-text\" id=\"fName\" style=\"width: 100px\">First Name</span>\n            </div>\n            <input type=\"text\" class=\"form-control\" aria-describedby=\"inputGroupPrepend\" placeholder=\"\" name=\"firstName\"\n                   name=\"firstName\"\n                   [(ngModel)]=\"firstName\" required>\n          </div>\n          <div class=\"input-group\" style=\"margin-top:10px; margin-bottom:10px\">\n            <div class=\"input-group-prepend\">\n              <span class=\"input-group-text\" id=\"lName\" style=\"width: 100px\">Last Name</span>\n            </div>\n            <input type=\"text\" class=\"form-control\" aria-describedby=\"inputGroupPrepend\" placeholder=\"\" name=\"lastName\"\n                   name=\"lastName\"\n                   [(ngModel)]=\"lastName\" required>\n          </div>\n          <div class=\"input-group\" style=\"margin-top:10px; margin-bottom:10px\">\n            <div class=\"input-group-prepend\">\n              <span class=\"input-group-text\" id=\"email\" style=\"width: 100px\">Email</span>\n            </div>\n            <input type=\"email\" class=\"form-control\" aria-describedby=\"inputGroupPrepend\" placeholder=\"user@example.com\"\n                   name=\"email\"\n                   name=\"email\" [(ngModel)]=\"email\" required>\n\n          </div>\n\n          <div class=\"input-group\" style=\"margin-top:10px; margin-bottom:10px\">\n            <div class=\"input-group-prepend\">\n              <span class=\"input-group-text\" id=\"userType\" style=\"width: 100px\">User Type</span>\n            </div>\n\n            <select class=\"form-control\" aria-describedby=\"inputGroupPrepend\" id=\"userType\" [(ngModel)]=\"userType\"\n                    name=\"userType\">\n              <option selected disabled>Select</option>\n              <option *ngFor=\"let o of options\">\n                {{o.name}}\n              </option>\n            </select>\n          </div>\n          <div *ngIf=\"userType === 'Vendor'\" class=\"input-group\" style=\"margin-top:10px; margin-bottom:10px\">\n              <div class=\"input-group-prepend\">\n                <span class=\"input-group-text\" id=\"vendorType\" style=\"width: 100px\">Vendor Type</span>\n              </div>\n  \n              <select class=\"form-control\" aria-describedby=\"inputGroupPrepend\" id=\"vendorType\" [(ngModel)]=\"vendorType\"\n                      name=\"vendorType\">\n                <option selected disabled>Select</option>\n                <option *ngFor=\"let o of vendorOptions\">\n                  {{o.name}}\n                </option>\n              </select>\n            </div>\n          <div class=\"row justify-content-center\">\n              <input type=\"submit\" style=\"margin: 20 auto;\" type=\"submit\" class=\"btn btn-success\" (click)=\"signUp()\">\n          </div>\n        </div>\n      </div>\n    </div>\n  </div>\n</div>\n"

/***/ }),

/***/ "./src/app/SignUpComponent/signup.component.ts":
/*!*****************************************************!*\
  !*** ./src/app/SignUpComponent/signup.component.ts ***!
  \*****************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
var core_1 = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
var login_service_1 = __webpack_require__(/*! ../aadhar-login-component/login.service */ "./src/app/aadhar-login-component/login.service.ts");
var router_1 = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
var session_manager_service_1 = __webpack_require__(/*! ../SessionManager/session-manager.service */ "./src/app/SessionManager/session-manager.service.ts");
var SignUpComponent = /** @class */ (function () {
    function SignUpComponent(loginService, router, sessionManager) {
        this.loginService = loginService;
        this.router = router;
        this.sessionManager = sessionManager;
        this.options = [
            { name: "Customer", value: 1 },
            { name: "Vendor", value: 2 }
        ];
        this.vendorOptions = [
            { name: "UberGo", value: 1 },
            { name: "UberAuto", value: 2 },
            { name: "Moto", value: 3 },
            { name: "Bus", value: 4 },
            { name: "Subway", value: 5 }
        ];
    }
    SignUpComponent.prototype.signUp = function () {
        var _this = this;
        var message = "Please enter the following mandatory fields {";
        var flag = false;
        if (null == this.firstName || this.firstName.length == 0) {
            message = message + " firstname, ";
            flag = true;
        }
        if (null == this.lastName || this.lastName.length == 0) {
            message = message + " lastname, ";
            flag = true;
        }
        if (null == this.aadhar || this.aadhar.length == 0) {
            message = message + " aadhaar, ";
            flag = true;
        }
        if (null == this.email || this.email.length == 0) {
            message = message + " email, ";
            flag = true;
        }
        if (null == this.phoneNo || this.phoneNo.toString().length == 0) {
            message = message + " mobile, ";
            flag = true;
        }
        if (null == this.userType || this.userType.length == 0) {
            message = message + " usertype ";
            flag = true;
        }
        if (null != this.userType && this.userType == 'Vendor') {
            if (null == this.vendorType || this.vendorType.length == 0) {
                message = message + " ,vendorType ";
                flag = true;
            }
        }
        if (flag) {
            message = message + " } ";
            alert(message);
            return;
        }
        else {
            var re = /^(([^<>()[\]\\.,;:\s@\"]+(\.[^<>()[\]\\.,;:\s@\"]+)*)|(\".+\"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
            if (!re.test(this.email)) {
                alert('Please enter a valid email address.');
                return;
            }
            if (this.phoneNo.toString().length != 10) {
                alert('Please enter a valid 10 digit mobile number. (' + this.phoneNo.toString().length + ')');
                return;
            }
            if (this.aadhar.toString().length != 12) {
                alert('Please enter a valid 12 digit aadhaar number');
                return;
            }
        }
        if (this.vendorType == null || this.vendorType.length == 0) {
            this.vendorType = "N.A.";
        }
        this.loginService.signup(this.firstName, this.lastName, this.aadhar.toString(), this.phoneNo.toString(), this.email, this.userType, this.vendorType).then(function (res) {
            if (res.result === 400) {
                //TODO: Show in UI
                alert("User with AADHAAR and email provided, already exists.");
            }
            else {
                _this.sessionManager.setUserSession(res.result);
                alert('SignUp Successful! Please login now.');
                _this.router.navigateByUrl('/login');
            }
        });
    };
    SignUpComponent.prototype.ngOnInit = function () {
    };
    SignUpComponent = __decorate([
        core_1.Component({
            selector: 'signup-component',
            template: __webpack_require__(/*! ./signup.component.html */ "./src/app/SignUpComponent/signup.component.html"),
            styles: [__webpack_require__(/*! ../aadhar-login-component/login.component.css */ "./src/app/aadhar-login-component/login.component.css")]
        }),
        __metadata("design:paramtypes", [login_service_1.LoginService,
            router_1.Router,
            session_manager_service_1.SessionManagerService])
    ], SignUpComponent);
    return SignUpComponent;
}());
exports.SignUpComponent = SignUpComponent;


/***/ }),

/***/ "./src/app/VendorComponent/vendor.component.html":
/*!*******************************************************!*\
  !*** ./src/app/VendorComponent/vendor.component.html ***!
  \*******************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<div class=\"container\">\n    <div class=\"row\">\n        <div class=\"col-sm\">\n        <div class=\"card\" style=\"width: 30rem\">\n                <h5 class=\"card-header bg-primary text-white\">Scanner</h5>\n                <div class=\"card-body\">\n                    <div class=\"card-text\">\n                    <qr-scanner *ngIf=\"openForScan\" [vendorData]=\"aadhaarNo\" (qrData)=\"sendSwipeRequest($event)\" ></qr-scanner>\n                    <div *ngIf=\"!openForScan\" style=\"width: 400px; height: 400px; background-color: black;\"></div>\n                </div>\n                    <br />\n                    <div class=\"alert alert-success\" role=\"alert\" *ngIf=\"showAlertMessage\">\n                            {{alertMessage}}\n                    </div>\n                    <p>\n                            <strong>Customer Aadhaar: </strong>{{ customerAadhaar }}\n                    </p>\n                    <br />\n                    <button class=\"btn btn-primary\" (click)=\"openAgain()\" *ngIf=\"!openForScan\">Scan</button>\n                    <button class=\"btn btn-danger\" (click)=\"close()\" *ngIf=\"openForScan\">Close</button>\n                </div>\n                </div>\n        </div>\n        <div class=\"col-sm\">\n            <div class=\"card\" style=\"width: 30rem\">\n                <h5 class=\"card-header bg-success text-white\">Transactions</h5>\n                <div class=\"card-body\">\n                    <div class=\"card-text\">\n                            <div *ngFor=\"let transaction of transactionDetails\">\n                               <div class=\"card\">\n                                    <h5 *ngIf=\"transaction.fare != undefined\"class=\"card-header\">{{transaction.fare}}</h5>\n                                    <h5 *ngIf=\"transaction.fare === undefined\"class=\"card-header bg-danger text-white\">Ongoing Transaction</h5>\n                                    <div class=\"card-body\">\n                                        <div class=\"card-text\">\n                                            From : {{this.transaction.from}}\n                                            <br />\n                                            Date : {{this.transaction.date}}\n                                        </div>\n                                    </div>\n                               </div>\n                               <br />\n                            </div>\n                    </div>\n                </div>\n            </div>\n        </div>\n    </div>\n</div>\n\n\n\n"

/***/ }),

/***/ "./src/app/VendorComponent/vendor.component.ts":
/*!*****************************************************!*\
  !*** ./src/app/VendorComponent/vendor.component.ts ***!
  \*****************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
var core_1 = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
var service_service_1 = __webpack_require__(/*! ../service/service.service */ "./src/app/service/service.service.ts");
var session_manager_service_1 = __webpack_require__(/*! ../SessionManager/session-manager.service */ "./src/app/SessionManager/session-manager.service.ts");
var router_1 = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
var VendorComponent = /** @class */ (function () {
    function VendorComponent(serviceService, sessionServiceManager, route) {
        var _this = this;
        this.serviceService = serviceService;
        this.sessionServiceManager = sessionServiceManager;
        this.route = route;
        this.aadhaarNo = "321";
        this.vendorType = "Bus";
        this.openForScan = false;
        this.showAlertMessage = false;
        this.transactionDetails = [];
        this.serviceService.getTransactions(this.aadhaarNo, "vendor").then(function (res) {
            _this.transactionDetails = res;
        });
    }
    VendorComponent.prototype.ngOnInit = function () {
    };
    VendorComponent.prototype.showAlert = function () {
        setTimeout(function () {
            this.showAlertMessage = true;
        }, 2000);
    };
    VendorComponent.prototype.sendSwipeRequest = function (qrData) {
        var _this = this;
        console.log(qrData);
        this.customerAadhaar = qrData.customerAadhaar;
        if (this.openForScan) {
            this.serviceService.swipe(qrData.customerAadhaar, this.aadhaarNo, qrData.location, this.vendorType).then(function (response) {
                if (response.result === 200) {
                    _this.alertMessage = "Scanned Successfull !";
                    _this.showAlert();
                }
                else if (response.result === 400) {
                    _this.openForScan = true;
                    _this.alertMessage = "Insufficient funds !";
                    _this.showAlert();
                }
            });
            this.openForScan = false;
        }
    };
    VendorComponent.prototype.openAgain = function () {
        this.openForScan = true;
    };
    VendorComponent.prototype.close = function () {
        console.log("Close");
        this.openForScan = false;
    };
    __decorate([
        core_1.Input(),
        __metadata("design:type", String)
    ], VendorComponent.prototype, "aadhaarNo", void 0);
    __decorate([
        core_1.Input(),
        __metadata("design:type", String)
    ], VendorComponent.prototype, "vendorType", void 0);
    VendorComponent = __decorate([
        core_1.Component({
            selector: 'vendor',
            template: __webpack_require__(/*! ./vendor.component.html */ "./src/app/VendorComponent/vendor.component.html")
        }),
        __metadata("design:paramtypes", [service_service_1.ServiceService, session_manager_service_1.SessionManagerService, router_1.Router])
    ], VendorComponent);
    return VendorComponent;
}());
exports.VendorComponent = VendorComponent;


/***/ }),

/***/ "./src/app/WindowRef/window-ref.service.ts":
/*!*************************************************!*\
  !*** ./src/app/WindowRef/window-ref.service.ts ***!
  \*************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
var core_1 = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
function _window() {
    // return the global native browser window object
    return window;
}
var WindowRefService = /** @class */ (function () {
    function WindowRefService() {
    }
    Object.defineProperty(WindowRefService.prototype, "nativeWindow", {
        get: function () {
            return _window();
        },
        enumerable: true,
        configurable: true
    });
    WindowRefService = __decorate([
        core_1.Injectable()
    ], WindowRefService);
    return WindowRefService;
}());
exports.WindowRefService = WindowRefService;


/***/ }),

/***/ "./src/app/aadhar-login-component/login.component.css":
/*!************************************************************!*\
  !*** ./src/app/aadhar-login-component/login.component.css ***!
  \************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = ""

/***/ }),

/***/ "./src/app/aadhar-login-component/login.component.html":
/*!*************************************************************!*\
  !*** ./src/app/aadhar-login-component/login.component.html ***!
  \*************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<div class=\"col-md-12 col-lg-12 col-xs-12 col-sm-12\" *ngIf=\"!moveToAuth\" style=\"background-image: url('../../assets/background/METRO.jpg'); height: 100%;\n\n/* Center and scale the image nicely */\nbackground-position: center;\nbackground-repeat: no-repeat;\nbackground-size: cover;   min-height:800px\">\n  <div class=\"row\">\n    <div class=\"col-md-4 col-lg-4 col-xs-6 col-md-offset-4\">\n    </div>\n    <div class=\"col-md-4 col-lg-4 col-xs-6 col-md-offset-4\">\n\n      <div class=\"card card-primary card-inverse\" style=\"margin-top:35%\">\n        <div class=\"card-header\" style=\"color: #fff;background-color: #094162;border-color: #2e6da4;\">\n          <h5 align=\"center\">Login</h5>\n        </div>\n        <div class=\"card-body\">\n          <div class=\"row justify-content-center\">\n            <img src=\"../../assets/background/digital.jpg\" style=\"width:300px; height:200px\"/>\n          </div>\n          <div class=\"form\">\n            <div class=\"input-group\" style=\"margin-top:10px; margin-bottom:10px\">\n              <div class=\"input-group-prepend\">\n                <span class=\"input-group-text\" id=\"aadhaar\" style=\"width: 100px\">Aadhaar</span>\n              </div>\n              <input type=\"text\" class=\"form-control\" aria-describedby=\"inputGroupPrepend\" id=\"aadharInput\"\n                     placeholder=\" XXXX-XXXX-XXXX \"\n                      name=\"aadharId\" [(ngModel)]=\"aadhar\" required>\n            </div>\n            <div class=\"row justify-content-center\">\n              <button style=\"margin-top: 20px\" type=\"submit\" class=\"btn btn-success\" (click)=\"tryLoggingIn()\">Request\n                OTP\n              </button>\n            </div>\n          </div>\n        </div>\n      </div>\n    </div>\n    <div class=\"col-md-4 col-lg-4 col-xs-6 col-md-offset-4\">\n\n    </div>\n  </div>\n</div>\n<div class=\"col-md-12 col-lg-12 col-xs-12 col-sm-12\" *ngIf=\"moveToAuth\" style=\"background-image: url('../../assets/background/METRO.jpg'); height: 100%;\n\n/* Center and scale the image nicely */\nbackground-position: center;\nbackground-repeat: no-repeat;\nbackground-size: cover;   min-height:800px\">\n  <div class=\"row\">\n    <div class=\"col-md-4 col-lg-4 col-xs-6 col-md-offset-4\">\n    </div>\n    <div class=\"col-md-4 col-lg-4 col-xs-6 col-md-offset-4\">\n      <div class=\"card card-primary card-inverse\" style=\"margin-top:35%\">\n        <div class=\"card-header\" style=\"color: #fff;background-color: #094162;border-color: #2e6da4;\">\n          <h5 align=\"center\">OTP Authentication</h5>\n        </div>\n        <div class=\"card-body\">\n          <div class=\"row justify-content-center\">\n            <img src=\"../../assets/background/digital.jpg\" style=\"width:300px; height:200px\"/>\n          </div>\n          <div class=\"form\">\n            <div class=\"input-group\" style=\"margin-top:10px; margin-bottom:10px\">\n              <div class=\"input-group-prepend\">\n                <span class=\"input-group-text\" id=\"otp\" style=\"width: 100px\">OTP</span>\n              </div>\n              <input type=\"text\" class=\"form-control\" aria-describedby=\"inputGroupPrepend\" id=\"otpInput\"\n                     placeholder=\" XXXX \" #sourc name=\"aadharId\"\n                     [(ngModel)]=\"code\" required>\n            </div>\n            <div class=\"row justify-content-center\">\n              <button style=\"margin-top: 20px\" type=\"submit\" class=\"btn btn-success\" (click)=\"verifyCode()\">Submit\n              </button>\n            </div>\n          </div>\n        </div>\n      </div>\n    </div>\n  </div>\n</div>\n"

/***/ }),

/***/ "./src/app/aadhar-login-component/login.component.ts":
/*!***********************************************************!*\
  !*** ./src/app/aadhar-login-component/login.component.ts ***!
  \***********************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
var core_1 = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
var login_service_1 = __webpack_require__(/*! ./login.service */ "./src/app/aadhar-login-component/login.service.ts");
var router_1 = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
var session_manager_service_1 = __webpack_require__(/*! ../SessionManager/session-manager.service */ "./src/app/SessionManager/session-manager.service.ts");
var service_service_1 = __webpack_require__(/*! ../service/service.service */ "./src/app/service/service.service.ts");
var LoginComponent = /** @class */ (function () {
    function LoginComponent(loginService, router, service, sessionManagerService) {
        this.loginService = loginService;
        this.router = router;
        this.service = service;
        this.sessionManagerService = sessionManagerService;
        this.loggedIn = false;
        this.moveToAuth = false;
    }
    LoginComponent.prototype.tryLoggingIn = function () {
        var _this = this;
        console.log(this.aadhar);
        this.loginService.tryLoggingIn(this.aadhar).then(function (res) {
            _this.phoneNumber = res.result;
            console.log(_this.phoneNumber);
        });
        this.moveToAuth = true;
    };
    LoginComponent.prototype.verifyCode = function () {
        var _this = this;
        console.log(this.code);
        this.loginService.verifyCode(this.code, this.phoneNumber, this.aadhar).then((function (res) {
            if (res.result === 401) {
                //TODO: Show in UI
                alert("Oops! OTP entered is incorrect");
                _this.setLoggedIn(false);
            }
            else {
                _this.sessionManagerService.setUserSession(res.result);
                _this.sessionManagerService.getGetUserDetails(res.result);
                _this.setLoggedIn(true);
                _this.router.navigateByUrl("/home");
                _this.setLoggedIn(true);
            }
        }));
    };
    LoginComponent.prototype.setLoggedIn = function (value) {
        this.service.setLoggedIn(value);
    };
    LoginComponent.prototype.ngOnInit = function () {
    };
    LoginComponent = __decorate([
        core_1.Component({
            selector: 'login-component',
            template: __webpack_require__(/*! ./login.component.html */ "./src/app/aadhar-login-component/login.component.html"),
            styles: [__webpack_require__(/*! ./login.component.css */ "./src/app/aadhar-login-component/login.component.css")]
        }),
        __metadata("design:paramtypes", [login_service_1.LoginService,
            router_1.Router,
            service_service_1.ServiceService,
            session_manager_service_1.SessionManagerService])
    ], LoginComponent);
    return LoginComponent;
}());
exports.LoginComponent = LoginComponent;


/***/ }),

/***/ "./src/app/aadhar-login-component/login.service.ts":
/*!*********************************************************!*\
  !*** ./src/app/aadhar-login-component/login.service.ts ***!
  \*********************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
var core_1 = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
var http_1 = __webpack_require__(/*! @angular/common/http */ "./node_modules/@angular/common/fesm5/http.js");
// let headers =  {
//   headers: new  HttpHeaders({
//     "X-Parse-Application-Id": "myAppId",
//     "Content-Type": "application/json",
//     "X-Parse-REST-API-Key": "myRestKey"
//   })
// };
//
// let options = new RequestOptions({ headers: headers });
var LoginService = /** @class */ (function () {
    function LoginService(http) {
        this.http = http;
        this.baseUri = "http://ec2-13-232-98-71.ap-south-1.compute.amazonaws.com/parse/";
    }
    LoginService.prototype.tryLoggingIn = function (aadharNo) {
        var httpOptions = {
            headers: new http_1.HttpHeaders({
                "X-Parse-Application-Id": "myAppId",
                "Content-Type": "application/json",
                "X-Parse-REST-API-Key": "myRestKey"
            })
        };
        var post_body = {
            "aadhar": aadharNo
        };
        return this.http.post(this.baseUri + "functions/aadhar_auth", post_body, httpOptions)
            .toPromise()
            .then(function (res) { return res; })
            .catch(this.handleError);
    };
    LoginService.prototype.verifyCode = function (code, number, aadhar) {
        var headers = { headers: new http_1.HttpHeaders()
                .set('X-Parse-Application-Id', "myAppId")
                .set('Content-Type', "application/json")
                .set("X-Parse-REST-API-Key", "myRestKey") };
        var post_body = {
            "code": code,
            "number": number,
            "aadhar": aadhar
        };
        return this.http.post(this.baseUri + "functions/verify", post_body, headers)
            .toPromise()
            .then(function (res) { return res; });
    };
    LoginService.prototype.getUserDetails = function (aadhar) {
        var headers = { headers: new http_1.HttpHeaders()
                .set('X-Parse-Application-Id', "myAppId")
                .set('Content-Type', "application/json")
                .set("X-Parse-REST-API-Key", "myRestKey") };
        var post_body = {
            "aadhar": aadhar
        };
        return this.http.post(this.baseUri + "functions/getDetails", post_body, headers)
            .toPromise()
            .then(function (res) { return res; });
    };
    LoginService.prototype.signup = function (fname, lname, aadhar, phone, email, userType, vendorType) {
        var headers = { headers: new http_1.HttpHeaders()
                .set('X-Parse-Application-Id', "myAppId")
                .set('Content-Type', "application/json")
                .set("X-Parse-REST-API-Key", "myRestKey") };
        var post_body = {
            "fname": fname,
            "lname": lname,
            "aadhar": aadhar,
            "phoneNumber": phone,
            "email": email,
            "userType": userType,
            "vendorType": vendorType
        };
        return this.http.post(this.baseUri + "functions/signup", post_body, headers)
            .toPromise()
            .then(function (res) { return res; });
    };
    LoginService.prototype.handleError = function (error) {
        console.log('Error From Service: ' + error);
        return Promise.reject(error.message || error);
    };
    LoginService.prototype.getDetails = function () {
        var headers = { headers: new http_1.HttpHeaders()
                .set('X-Parse-Application-Id', "myAppId")
                .set('Content-Type', "application/json")
                .set("X-Parse-REST-API-Key", "myRestKey") };
        return this.http.post(this.baseUri + "functions/getCurrent", {}, headers)
            .toPromise()
            .then(function (res) { return res; });
    };
    LoginService = __decorate([
        core_1.Injectable({
            providedIn: 'root'
        }),
        __metadata("design:paramtypes", [http_1.HttpClient])
    ], LoginService);
    return LoginService;
}());
exports.LoginService = LoginService;
var ResponseObj = /** @class */ (function () {
    function ResponseObj() {
    }
    return ResponseObj;
}());
exports.ResponseObj = ResponseObj;


/***/ }),

/***/ "./src/app/app.component.css":
/*!***********************************!*\
  !*** ./src/app/app.component.css ***!
  \***********************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = ".myBody {\n  margin: 100px 50px;\n}\n"

/***/ }),

/***/ "./src/app/app.component.html":
/*!************************************!*\
  !*** ./src/app/app.component.html ***!
  \************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<app-nav></app-nav>\n\n<div class=\"myBody\">\n\n  <router-outlet></router-outlet>\n\n</div>\n\n<app-footer></app-footer>"

/***/ }),

/***/ "./src/app/app.component.ts":
/*!**********************************!*\
  !*** ./src/app/app.component.ts ***!
  \**********************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
var core_1 = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
var AppComponent = /** @class */ (function () {
    function AppComponent() {
        this.title = 'Movehack';
    }
    AppComponent.prototype.updateLogIn = function () {
        this.loggedIn = true;
    };
    AppComponent = __decorate([
        core_1.Component({
            selector: 'app-root',
            template: __webpack_require__(/*! ./app.component.html */ "./src/app/app.component.html"),
            styles: [__webpack_require__(/*! ./app.component.css */ "./src/app/app.component.css")]
        })
    ], AppComponent);
    return AppComponent;
}());
exports.AppComponent = AppComponent;


/***/ }),

/***/ "./src/app/app.module.ts":
/*!*******************************!*\
  !*** ./src/app/app.module.ts ***!
  \*******************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
var app_component_1 = __webpack_require__(/*! ./app.component */ "./src/app/app.component.ts");
var platform_browser_1 = __webpack_require__(/*! @angular/platform-browser */ "./node_modules/@angular/platform-browser/fesm5/platform-browser.js");
var core_1 = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
var forms_1 = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm5/forms.js");
var router_1 = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
var http_1 = __webpack_require__(/*! @angular/http */ "./node_modules/@angular/http/fesm5/http.js");
var http_2 = __webpack_require__(/*! @angular/common/http */ "./node_modules/@angular/common/fesm5/http.js");
var forms_2 = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm5/forms.js");
var nav_component_1 = __webpack_require__(/*! ./nav/nav.component */ "./src/app/nav/nav.component.ts");
var footer_component_1 = __webpack_require__(/*! ./footer/footer.component */ "./src/app/footer/footer.component.ts");
var home_component_1 = __webpack_require__(/*! ./home/home.component */ "./src/app/home/home.component.ts");
var wallet_component_1 = __webpack_require__(/*! ./wallet/wallet.component */ "./src/app/wallet/wallet.component.ts");
var login_component_1 = __webpack_require__(/*! ./aadhar-login-component/login.component */ "./src/app/aadhar-login-component/login.component.ts");
var window_ref_service_1 = __webpack_require__(/*! ./WindowRef/window-ref.service */ "./src/app/WindowRef/window-ref.service.ts");
var login_service_1 = __webpack_require__(/*! ./aadhar-login-component/login.service */ "./src/app/aadhar-login-component/login.service.ts");
var core_2 = __webpack_require__(/*! @agm/core */ "./node_modules/@agm/core/index.js");
var agm_direction_1 = __webpack_require__(/*! agm-direction */ "./node_modules/agm-direction/fesm5/agm-direction.js"); // agm-direction
var ngx_google_places_autocomplete_1 = __webpack_require__(/*! ngx-google-places-autocomplete */ "./node_modules/ngx-google-places-autocomplete/bundles/ngx-google-places-autocomplete.umd.js");
var angular_font_awesome_1 = __webpack_require__(/*! angular-font-awesome */ "./node_modules/angular-font-awesome/dist/angular-font-awesome.es5.js");
var signup_component_1 = __webpack_require__(/*! ./SignUpComponent/signup.component */ "./src/app/SignUpComponent/signup.component.ts");
var ngx_webstorage_service_1 = __webpack_require__(/*! ngx-webstorage-service */ "./node_modules/ngx-webstorage-service/esm5/ngx-webstorage-service.js");
var ngx_qrcode2_1 = __webpack_require__(/*! ngx-qrcode2 */ "./node_modules/ngx-qrcode2/index.js");
var qr_code_component_1 = __webpack_require__(/*! ./QrCodeComponent/qr-code.component */ "./src/app/QrCodeComponent/qr-code.component.ts");
var ngx_scanner_1 = __webpack_require__(/*! @zxing/ngx-scanner */ "./node_modules/@zxing/ngx-scanner/esm5/zxing-ngx-scanner.js");
var animations_1 = __webpack_require__(/*! @angular/platform-browser/animations */ "./node_modules/@angular/platform-browser/fesm5/animations.js");
var pay_component_1 = __webpack_require__(/*! ./pay/pay.component */ "./src/app/pay/pay.component.ts");
var qr_scanner_component_1 = __webpack_require__(/*! ./QrScannerComponent/qr-scanner.component */ "./src/app/QrScannerComponent/qr-scanner.component.ts");
var vendor_component_1 = __webpack_require__(/*! ./VendorComponent/vendor.component */ "./src/app/VendorComponent/vendor.component.ts");
var user_transaction_component_1 = __webpack_require__(/*! ./user-transaction/user-transaction.component */ "./src/app/user-transaction/user-transaction.component.ts");
exports.httpOptions = {
    headers: new http_2.HttpHeaders({
        "X-Parse-Application-Id": "myAppId",
        "Content-Type": "application/json",
        "X-Parse-REST-API-Key": "myRestKey"
    })
};
var AppModule = /** @class */ (function () {
    function AppModule() {
    }
    AppModule = __decorate([
        core_1.NgModule({
            declarations: [
                app_component_1.AppComponent,
                footer_component_1.FooterComponent,
                nav_component_1.NavComponent,
                home_component_1.HomeComponent,
                login_component_1.LoginComponent,
                wallet_component_1.WalletComponent,
                signup_component_1.SignUpComponent,
                qr_code_component_1.QrCodeComponent,
                qr_scanner_component_1.QrScannerComponent,
                user_transaction_component_1.UserTransactionComponent,
                pay_component_1.PayComponent,
                vendor_component_1.VendorComponent,
                user_transaction_component_1.UserTransactionComponent
            ],
            imports: [
                platform_browser_1.BrowserModule,
                animations_1.BrowserAnimationsModule,
                angular_font_awesome_1.AngularFontAwesomeModule,
                core_2.AgmCoreModule.forRoot({
                    apiKey: 'AIzaSyCLQRpy9eTdiVhK4CvjsNWrCaFNLOSBaio',
                    libraries: ['places']
                }),
                agm_direction_1.AgmDirectionModule,
                forms_1.FormsModule,
                http_1.HttpModule,
                http_2.HttpClientModule,
                forms_2.ReactiveFormsModule,
                ngx_google_places_autocomplete_1.GooglePlaceModule,
                ngx_webstorage_service_1.StorageServiceModule,
                ngx_qrcode2_1.NgxQRCodeModule,
                ngx_scanner_1.ZXingScannerModule.forRoot(),
                router_1.RouterModule.forRoot([
                    {
                        path: '',
                        redirectTo: '/login',
                        pathMatch: 'full'
                    }, {
                        path: 'home',
                        component: home_component_1.HomeComponent
                    }, {
                        path: 'login',
                        component: login_component_1.LoginComponent
                    },
                    {
                        path: 'wallet',
                        component: wallet_component_1.WalletComponent
                    },
                    {
                        path: 'signup',
                        component: signup_component_1.SignUpComponent
                    }, {
                        path: 'pay',
                        component: pay_component_1.PayComponent
                    },
                    {
                        path: 'vendor',
                        component: vendor_component_1.VendorComponent
                    }, {
                        path: 'transaction',
                        component: user_transaction_component_1.UserTransactionComponent
                    }
                ])
            ],
            providers: [window_ref_service_1.WindowRefService, login_service_1.LoginService],
            bootstrap: [app_component_1.AppComponent]
        })
    ], AppModule);
    return AppModule;
}());
exports.AppModule = AppModule;


/***/ }),

/***/ "./src/app/footer/footer.component.css":
/*!*********************************************!*\
  !*** ./src/app/footer/footer.component.css ***!
  \*********************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = ""

/***/ }),

/***/ "./src/app/footer/footer.component.html":
/*!**********************************************!*\
  !*** ./src/app/footer/footer.component.html ***!
  \**********************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<nav class=\"navbar fixed-bottom navbar-expand navbar-light bg-light\">\n  <div class=\"navbar-text m-auto\">\n    Made with <span style=\"color: red;\">♥</span>️ by Alpha Omega\n  </div>\n</nav>\n"

/***/ }),

/***/ "./src/app/footer/footer.component.ts":
/*!********************************************!*\
  !*** ./src/app/footer/footer.component.ts ***!
  \********************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
var core_1 = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
var FooterComponent = /** @class */ (function () {
    function FooterComponent() {
    }
    FooterComponent.prototype.ngOnInit = function () {
    };
    FooterComponent = __decorate([
        core_1.Component({
            selector: 'app-footer',
            template: __webpack_require__(/*! ./footer.component.html */ "./src/app/footer/footer.component.html"),
            styles: [__webpack_require__(/*! ./footer.component.css */ "./src/app/footer/footer.component.css")]
        }),
        __metadata("design:paramtypes", [])
    ], FooterComponent);
    return FooterComponent;
}());
exports.FooterComponent = FooterComponent;


/***/ }),

/***/ "./src/app/home/TravelOptions.ts":
/*!***************************************!*\
  !*** ./src/app/home/TravelOptions.ts ***!
  \***************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

Object.defineProperty(exports, "__esModule", { value: true });
var TravelOptions = /** @class */ (function () {
    function TravelOptions(routeDescription, routePreference, comfortPercentage, startAddress, endAddress, totalDistance, totalDuration, totalFare, route) {
        this.selected = false;
        this.route = route;
        this.comfortPercentage = comfortPercentage;
        this.routeDescription = routeDescription;
        this.routePreference = routePreference;
        this.startAddress = startAddress;
        this.endAddress = endAddress;
        this.totalDistance = totalDistance;
        this.totalDuration = totalDuration;
        this.totalFare = totalFare;
    }
    return TravelOptions;
}());
exports.TravelOptions = TravelOptions;
var RouteForMap = /** @class */ (function () {
    function RouteForMap(origin, destination, markerOptions) {
        this.origin = origin;
        this.destination = destination;
        this.markerOptions = markerOptions;
    }
    return RouteForMap;
}());
exports.RouteForMap = RouteForMap;
var TransitDetail = /** @class */ (function () {
    function TransitDetail(vehicleType) {
        this.vehicleType = vehicleType;
    }
    return TransitDetail;
}());
exports.TransitDetail = TransitDetail;
var LatLng = /** @class */ (function () {
    function LatLng(lat, lng) {
        this.lat = lat;
        this.long = lng;
    }
    return LatLng;
}());
exports.LatLng = LatLng;
var Route = /** @class */ (function () {
    function Route(origin, destination, displayText, mode, travelTime, distance, fare, transitDetails) {
        this.origin = origin;
        this.destination = destination;
        this.displayText = displayText;
        this.mode = mode;
        this.travelTime = travelTime;
        this.distance = distance;
        this.fare = fare;
        if (undefined !== transitDetails || null != transitDetails) {
            this.transitDetails = transitDetails;
        }
    }
    return Route;
}());
exports.Route = Route;


/***/ }),

/***/ "./src/app/home/home.component.css":
/*!*****************************************!*\
  !*** ./src/app/home/home.component.css ***!
  \*****************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "agm-map {\n  height: 100vh;\n  widows: 180vh;\n}\n\n.card {\n  border-radius: 0px;\n}\n\n.spinner {\n  margin: 0px;\n  height: 28px;\n  width: 28px;\n  -webkit-animation: rotate 0.8s infinite linear;\n          animation: rotate 0.8s infinite linear;\n  border: 5px solid #fff;\n  border-right-color: transparent;\n  border-radius: 50%;\n}\n\n@-webkit-keyframes rotate {\n  0%    { -webkit-transform: rotate(0deg); transform: rotate(0deg); }\n  100%  { -webkit-transform: rotate(360deg); transform: rotate(360deg); }\n}\n\n@keyframes rotate {\n  0%    { -webkit-transform: rotate(0deg); transform: rotate(0deg); }\n  100%  { -webkit-transform: rotate(360deg); transform: rotate(360deg); }\n}\n"

/***/ }),

/***/ "./src/app/home/home.component.html":
/*!******************************************!*\
  !*** ./src/app/home/home.component.html ***!
  \******************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<div class=\"col-md-12 col-sm-12 col-lg-12 col-xs-12\" style=\"min-height:500px;padding: 0\">\n  <div class=\"row\">\n    <div class=\"col-md-4 col-lg-4 col-sm-12 col-xs-12\" style=\"padding: 0\">\n\n      <div class=\"col-md-12 col-sm-12 col-lg-12 col-xs-12\" style=\"padding: 0\">\n        <div class=\"card card-primary card-inverse\">\n          <div class=\"card-header\" style=\"color: #fff;background-color: #303F9F;\">\n            <div class=\"row\">\n              <div class=\"col-8\">\n                <h5>Map Directions</h5>\n              </div>\n              <div class=\"col\">\n                <div class=\"spinner pull pull-right\" *ngIf=\"routeDataRequestedAndNotRecieved\"></div>\n              </div>\n            </div>\n          </div>\n          <div class=\"card-body\">\n\n            <div class=\"form\">\n\n              <div class=\"input-group\" style=\"margin-top:10px; margin-bottom:10px\">\n                <div class=\"input-group-prepend\">\n                  <span style=\"width: 110px\" class=\"input-group-text\" id=\"inputGroupPrepend\">Source</span>\n                </div>\n                <input type=\"text\" class=\"form-control\" aria-describedby=\"inputGroupPrepend\" id=\"origin\" required\n                       #source>\n              </div>\n\n              <div class=\"input-group\" style=\"margin-top:10px; margin-bottom:10px\">\n                <div class=\"input-group-prepend\">\n                  <span style=\"width: 110px\" class=\"input-group-text\" id=\"inputGroupPrepend2\">Destination</span>\n                </div>\n                <input type=\"text\" class=\"form-control\" aria-describedby=\"inputGroupPrepend\" id=\"destination\" required\n                       #destination>\n              </div>\n              <div class=\"input-group\" style=\"margin-top:10px; margin-bottom:10px\"></div>\n              <button class=\"btn btn-primary\" (click)=findRoute(); [disabled]=\"routeDataRequestedAndNotRecieved\">Find\n                Routes <i class=\"far fa-compass\"></i>\n              </button>\n              <button class=\"btn btn-info\" style=\"margin-left:5px\" (click)=setCurrentPosition();>Locate Me <i\n                class=\"fas fa-street-view\"></i></button>\n            </div>\n          </div>\n        </div>\n      </div>\n\n      <div class=\"col-md-12 col-sm-12 col-lg-12 col-xs-12\" style=\"padding: 0\">\n        <div class=\"card card-primary card-inverse\" style=\"margin-top:10px\">\n          <div class=\"card-header\" style=\"color: #fff;background-color: #303F9F;\">\n            <h5>Available Routes</h5>\n          </div>\n          <div *ngIf=\"null!= routeList && routeList.length > 0\">\n            <div class=\"card\" *ngFor=\"let route of routeList\">\n              <div class=\"card-header\">\n                <div class=\"container\">\n                  <div class=\"row\">\n                    <div class=\"col\">\n                      <h5 style=\"color: #009688\">{{route.routeDescription}}</h5>\n                    </div>\n                    <div class=\"col\">\n                      <i class=\"fas fa-map-marked-alt pull-right\" style=\"cursor:pointer; padding-top: 10px\"\n                         (click)=\"loadOnMap(route)\" title=\"Show on Map\"></i>\n                    </div>\n                  </div>\n                </div>\n              </div>\n              <div class=\"card-body\">\n                <div class=\"container\">\n                  <div class=\"row justify-content-center\">\n                    <div class=\"col\"><h6><span style=\"color:#607D8B\">Total Distance</span> : <span\n                      style=\"color:#212121\"><b>{{route.totalDistance / 1000 | number : '0.0-2'}} Kms</b></span></h6>\n                    </div>\n                    <div class=\"col-auto\"><h6><span style=\"color:#607D8B\">Total Fare</span> : <span\n                      style=\"color:#212121\"><b>₹ {{route.totalFare}}</b></span></h6></div>\n                  </div>\n                  <div class=\"row\">\n                    <div class=\"col\"><h6><span style=\"color:#607D8B\">Total Time</span> : <span style=\"color:#212121\"><b>{{route.totalDuration / 60 | number : '1.0-2'}} mins</b></span>\n                    </h6></div>\n                  </div>\n                  <div class=\"row justify-content-center\">\n                    <div class=\"col-2\"><h6 style=\"color:#607D8B\">Comfort</h6></div>\n                    <div class=\"col\">\n                      <div class=\"progress\" style=\"height: 20px;\">\n                        <div class=\"progress-bar bg-warning progress-bar-striped progress-bar-animated\"\n                             role=\"progressbar\" [attr.aria-valuenow]=\"route.comfortPercentage\" aria-valuemin=\"0\"\n                             aria-valuemax=\"100\" [style.width]=\"route.comfortPercentage + '%'\">\n                          <b>{{route.comfortPercentage | number : '0.0-2'}}</b>\n                        </div>\n                      </div>\n                    </div>\n                  </div>\n                  <br>\n                  <div class=\"row justify-content-center\">\n                    <div class=\"col\">\n                      <div class=\"list-group\">\n                        <a class=\"list-group-item list-group-item-action flex-column align-items-start\"\n                           *ngFor=\"let routeDate of route.route, let i=index\">\n                          <div class=\"d-flex w-100 justify-content-between\">\n                            <h6 class=\"mb-1\" style=\"color: #E91E63\">{{letters[i]}}.&nbsp;{{routeDate.displayText}}</h6>\n                            <small style=\"color:#607D8B\" *ngIf=\"routeDate.mode == 'TRANSIT'\">\n                              ({{routeDate.transitDetails.vehicleType}})\n                            </small>\n                            <small style=\"color:#607D8B\" *ngIf=\"routeDate.mode != 'TRANSIT'\">({{routeDate.mode}})\n                            </small>\n                          </div>\n                          <div class=\"container\">\n                            <div class=\"row\" style=\"color:#607D8B\">\n                              <div class=\"col\" align=\"center\">\n                                <small>Distance : <b>{{routeDate.distance / 1000 | number : '1.0-2'}} Kms</b></small>\n                              </div>\n                              <div class=\"col\" align=\"center\">\n                                <small>Time : <b>{{routeDate.travelTime / 60 | number : '1.0-2'}} mins</b></small>\n                              </div>\n                              <div class=\"col\" align=\"center\">\n                                <small>Fare : <b>₹ {{routeDate.fare}}</b></small>\n                              </div>\n                            </div>\n                          </div>\n                        </a>\n                      </div>\n                    </div>\n                  </div>\n                </div>\n              </div>\n            </div>\n          </div>\n        </div>\n      </div>\n    </div>\n    <div class=\"col-md-8 col-lg-8 col-sm-12 col-xs-12\">\n      <div class=\"col-md-12 col-sm-12 col-lg-12 col-xs-12\"></div>\n      <div class=\"card card-primary card-inverse\">\n        <div class=\"card-header\" style=\"color: #fff;background-color: #303F9F;\">\n          <h5>Travel Route</h5>\n        </div>\n        <div class=\"card-body\">\n          <div class=\"container\" fxLayout=\"column\">\n            <div class=\"map\" fxFlex=\"100%\" #map>\n              <agm-map [latitude]=\"lat\" [longitude]=\"lng\" [style.height.px]=\"map.offsetHeight\" [zoom]=\"zoom\">\n                <ng-container *ngIf=\"!showMapDirections\">\n                  <agm-marker [latitude]=\"lat\" [longitude]=\"lng\"></agm-marker>\n                </ng-container>\n                <ng-container *ngIf=\"showMapDirections\">\n                  <agm-direction *ngFor=\"let waypoint of selectedMapRoute, let i=index\"\n                                 [origin]=\"waypoint.origin\" [destination]=\"waypoint.destination\"\n                                 [renderOptions]=\"renderOptions\" [markerOptions]=\"waypoint.markerOptions\"\n                  ></agm-direction>\n                  <!--markerOptions]=\"waypoint.markerOptions\"*/-->\n                </ng-container>\n              </agm-map>\n            </div>\n          </div>\n        </div>\n      </div>\n    </div>\n  </div>\n</div>\n"

/***/ }),

/***/ "./src/app/home/home.component.ts":
/*!****************************************!*\
  !*** ./src/app/home/home.component.ts ***!
  \****************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
var core_1 = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
var core_2 = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
var core_3 = __webpack_require__(/*! @agm/core */ "./node_modules/@agm/core/index.js");
var service_service_1 = __webpack_require__(/*! ../service/service.service */ "./src/app/service/service.service.ts");
var TravelOptions_1 = __webpack_require__(/*! ./TravelOptions */ "./src/app/home/TravelOptions.ts");
var session_manager_service_1 = __webpack_require__(/*! ../SessionManager/session-manager.service */ "./src/app/SessionManager/session-manager.service.ts");
var router_1 = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
var HomeComponent = /** @class */ (function () {
    function HomeComponent(mapsAPILoader, ngZone, mapuiservice, sessionManagerService, router) {
        this.mapsAPILoader = mapsAPILoader;
        this.ngZone = ngZone;
        this.mapuiservice = mapuiservice;
        this.sessionManagerService = sessionManagerService;
        this.router = router;
        this.routeDataRequestedAndNotRecieved = false;
        this.zoom = 16;
        this.routeList = [];
        this.showMapDirections = false;
        this.letters = ['A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z'];
        this.wayPointsMarkerOptions = [];
        this.markerOptions = {};
        this.renderOptions = {
            suppressMarkers: true,
        };
        var customerType = sessionManagerService.getUserType();
        //console.log()
        if (customerType == 'vendor' || customerType == 'Vendor') {
            this.router.navigateByUrl("/vendor");
        }
    }
    HomeComponent.prototype.setCurrentPosition = function () {
        var _this = this;
        if ("geolocation" in navigator) {
            navigator.geolocation.getCurrentPosition(function (position) {
                _this.lat = position.coords.latitude;
                _this.lng = position.coords.longitude;
                _this.showMapDirections = false;
                _this.routeDataRequestedAndNotRecieved = false;
                console.log("Current location", position, navigator, _this.lat, _this.lng);
            });
        }
    };
    HomeComponent.prototype.loadOnMap = function (route) {
        var _this = this;
        this.showMapDirections = false;
        this.routeList.forEach(function (data) {
            data.selected = false;
        });
        route.selected = true;
        this.selectedMapRoute = [];
        var j = 1;
        route.route.forEach(function (data) {
            console.log(data);
            var origin = { 'lat': data.origin.lat, 'lng': data.origin.long };
            var destination = { 'lat': data.destination.lat, 'lng': data.destination.long };
            var icon = '', destIcon;
            /*
            if (j == 1) {
              icon = '/assets/icons/start.png';
            } else {
              if (data.mode == 'TRANSIT') {
                if (null != data.transitDetails) {
                  if (data.transitDetails.vehicleType == 'BUS') {
                    icon = '/assets/icons/bus.png'
                  } else if (data.transitDetails.vehicleType == 'METRO') {
                    icon = '/assets/icons/metro.png'
                  }
                }
              } else {
                if (data.transitDetails.vehicleType == 'CAB') {
                  icon = '/assets/icons/cab.png';
                } else if (data.transitDetails.vehicleType == 'SHARE') {
                  icon = '/assets/icons/cab.png';
                } else if (data.transitDetails.vehicleType == 'MOTO') {
                  icon = '/assets/icons/bike.jpg';
                }
              }
            }
      
            if (j == route.route.length) {
              //Last One
              destIcon = '/assets/icons/dest.png';
              this.markerOptions = {
                'origin': {
                  'icon': icon
                },
                'destination': {
                  'icon': icon,
                  'label' : data.distance+'',
                  'opacity' : 0.8
                }
              }
            } else {
              this.markerOptions = {
                'origin': {
                  'icon': icon
                },
                'destination': {
                  'icon': '/aa.png',
                  'label' : data.distance+'',
                  'opacity' : 0.8
                }
              }
            }
            console.info(data, icon, destIcon, j)
            */
            icon = '/assets/icons/start.png';
            _this.markerOptions = {
                'origin': {
                    'icon': icon,
                    'label': _this.letters[j]
                },
                'destination': {
                    'icon': '/aa.png',
                    'label': '',
                    'opacity': 0.8
                }
            };
            _this.selectedMapRoute.push(new TravelOptions_1.RouteForMap(origin, destination, _this.markerOptions));
            j++;
            if (j == 26) {
                j = 0;
            }
        });
        this.showMapDirections = true;
    };
    HomeComponent.prototype.findRoute = function () {
        var _this = this;
        this.routeDataRequestedAndNotRecieved = true;
        console.log(this.origin, this.destination);
        this.mapuiservice.getRoute(this.origin, this.destination)
            .then(function (dataList) {
            console.log("Data from server", dataList);
            _this.routeList = [];
            var i = 0;
            dataList.forEach(function (data) {
                console.log("Route", data);
                if (i == 0) {
                    data.selected = true;
                    _this.loadOnMap(data);
                }
                else {
                    data.selected = false;
                }
                _this.routeList.push(data);
                i++;
            });
            _this.routeDataRequestedAndNotRecieved = false;
        });
    };
    HomeComponent.prototype.ngOnInit = function () {
        var _this = this;
        if (this.sessionManagerService.getUserSessionToken() === null || this.sessionManagerService.getUserSessionToken() === undefined) {
            this.router.navigateByUrl('/login');
        }
        this.setCurrentPosition();
        this.mapsAPILoader.load().then(function () {
            var sourceAutocomplete = new google.maps.places.Autocomplete(_this.sourceLocation.nativeElement, { types: ["address"] });
            var destinationAutoComplete = new google.maps.places.Autocomplete(_this.destinationLocation.nativeElement, { types: ["address"] });
            sourceAutocomplete.addListener("place_changed", function () {
                _this.ngZone.run(function () {
                    var place = sourceAutocomplete.getPlace();
                    if (place.geometry === undefined || place.geometry === null) {
                        return;
                    }
                    else {
                        _this.origin = { lat: place.geometry.location.lat(), lng: place.geometry.location.lng() };
                    }
                });
            });
            destinationAutoComplete.addListener("place_changed", function () {
                console.log("dd");
                _this.ngZone.run(function () {
                    var place = destinationAutoComplete.getPlace();
                    if (place.geometry === undefined || place.geometry === null) {
                        return;
                    }
                    else {
                        _this.destination = { lat: place.geometry.location.lat(), lng: place.geometry.location.lng() };
                    }
                });
            });
        });
    };
    __decorate([
        core_2.ViewChild('source'),
        __metadata("design:type", core_2.ElementRef)
    ], HomeComponent.prototype, "sourceLocation", void 0);
    __decorate([
        core_2.ViewChild('destination'),
        __metadata("design:type", core_2.ElementRef)
    ], HomeComponent.prototype, "destinationLocation", void 0);
    HomeComponent = __decorate([
        core_1.Component({
            selector: 'app-home',
            template: __webpack_require__(/*! ./home.component.html */ "./src/app/home/home.component.html"),
            styles: [__webpack_require__(/*! ./home.component.css */ "./src/app/home/home.component.css")],
        }),
        __metadata("design:paramtypes", [core_3.MapsAPILoader, core_2.NgZone, service_service_1.ServiceService,
            session_manager_service_1.SessionManagerService,
            router_1.Router])
    ], HomeComponent);
    return HomeComponent;
}());
exports.HomeComponent = HomeComponent;


/***/ }),

/***/ "./src/app/nav/nav.component.css":
/*!***************************************!*\
  !*** ./src/app/nav/nav.component.css ***!
  \***************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = ".myHover:hover {\n  color: white;\n}\n\n.white {\n  color: white\n}\n"

/***/ }),

/***/ "./src/app/nav/nav.component.html":
/*!****************************************!*\
  !*** ./src/app/nav/nav.component.html ***!
  \****************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<nav class=\"navbar navbar-expand navbar-dark fixed-top\" style=\"background-color: #263238\">\n  <a class=\"navbar-brand\" href=\"#\">\n    <img src=\"../../assets/icons/auto.png\" style=\"height:30px; padding-top: 5px\" class=\"d-inline-block align-top\">\n    Let's Move India\n  </a>\n  <button class=\"navbar-toggler\" type=\"button\" data-toggle=\"collapse\" data-target=\"#navbarNav\" aria-controls=\"navbarNav\"\n          aria-expanded=\"false\"\n          aria-label=\"Toggle navigation\">\n    <span class=\"navbar-toggler-icon\"></span>\n  </button>\n\n  <div class=\"collapse navbar-collapse\" id=\"navbarNav\">\n    \n    <ul class=\"navbar-nav mr-auto\">\n      <li class=\"nav-item active\" (click)=\"loadPage('home')\"\n          *ngIf=\"undefined != this.firstName && this.firstName.length > 0\"\n          style=\"cursor:pointer\">\n        <a class=\"nav-link white\">Home <span class=\"sr-only\">(current)</span></a>\n      </li>\n      <li class=\"nav-item\" (click)=\"loadPage('checkin')\"\n          *ngIf=\"undefined != this.firstName && this.firstName.length > 0\"\n          style=\"cursor:pointer\">\n        <a class=\"nav-link white\">Check In/Check Out<span class=\"sr-only\">(current)</span></a>\n      </li>\n      <li class=\"nav-item\" (click)=\"loadPage('login')\"\n          *ngIf=\"undefined == this.firstName || this.firstName.length == 0\"\n          style=\"cursor:pointer\">\n        <a class=\"nav-link white\">Login <span class=\"sr-only\">(current)</span></a>\n      </li>\n      <li class=\"nav-item\" (click)=\"loadPage('signup')\"\n          *ngIf=\"undefined == this.firstName || this.firstName.length == 0\"\n          style=\"cursor:pointer\">\n        <a class=\"nav-link white\">Signup <span class=\"sr-only\">(current)</span></a>\n      </li>\n    </ul>\n\n    <span class=\"navbar-text\" (click)=\"loadPage('wallet')\"\n          *ngIf=\"undefined != this.firstName && this.firstName.length > 0\"\n          style=\"cursor:pointer\">\n        <a class=\" white\" style=\"padding-right: 10px\">{{firstName}} &nbsp;{{lastName}}</a>\n    </span>\n    <span class=\"navbar-text\"\n          *ngIf=\"undefined != this.firstName && this.firstName.length > 0\"\n          style=\"cursor:pointer\" (click)=\"logout()\" style=\"cursor:pointer\">\n        <span class=\"white\">Logout</span>\n    </span>\n  </div>\n</nav>\n"

/***/ }),

/***/ "./src/app/nav/nav.component.ts":
/*!**************************************!*\
  !*** ./src/app/nav/nav.component.ts ***!
  \**************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
var core_1 = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
var router_1 = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
var session_manager_service_1 = __webpack_require__(/*! ../SessionManager/session-manager.service */ "./src/app/SessionManager/session-manager.service.ts");
var service_service_1 = __webpack_require__(/*! ../service/service.service */ "./src/app/service/service.service.ts");
var NavComponent = /** @class */ (function () {
    function NavComponent(router, sessionServiceManager, service) {
        this.router = router;
        this.sessionServiceManager = sessionServiceManager;
        this.service = service;
        this.firstName = null;
        this.lastName = "";
        this.aadhaar = "";
    }
    NavComponent.prototype.logout = function () {
        this.sessionServiceManager.unsetUserSession();
        this.loggedIn = false;
        this.router.navigateByUrl('/login');
    };
    NavComponent.prototype.loadPage = function (url) {
        console.log(url);
        switch (url) {
            case 'home':
                this.router.navigateByUrl('/home');
                break;
            case 'wallet':
                this.router.navigateByUrl('/wallet');
                break;
            case 'pay':
                this.router.navigateByUrl('/pay');
                break;
            case 'login':
                this.router.navigateByUrl('/login');
                break;
            case 'signup':
                this.router.navigateByUrl('/signup');
                break;
            case 'checkin':
                this.router.navigateByUrl('/pay');
                break;
        }
    };
    NavComponent.prototype.ngOnInit = function () {
        var _this = this;
        this.sessionToken = this.sessionServiceManager.getUserSessionToken();
        this.firstName = this.sessionServiceManager.getUserName();
        if (null === this.sessionToken || undefined === this.sessionToken) {
            this.loggedIn = false;
        }
        else {
            this.loggedIn = true;
        }
        this.subs = this.service.logMsg.subscribe(function (m) {
            _this.loggedIn = m;
            console.log("from S", m);
        });
        this.userDetailsSubscription = this.service.firstName.subscribe(function (m) {
            _this.firstName = m;
            _this.sessionServiceManager.setUserFirstName(m);
        });
        this.userDetailsSubscription = this.service.lastName.subscribe(function (m) {
            _this.lastName = m;
            _this.sessionServiceManager.setUserLastName(m);
        });
        this.userDetailsSubscription = this.service.mobile.subscribe(function (m) {
            _this.sessionServiceManager.setUserMobile(m);
        });
        this.userDetailsSubscription = this.service.aadhaar.subscribe(function (m) {
            _this.sessionServiceManager.setAdhar(m);
        });
        this.userDetailsSubscription = this.service.email.subscribe(function (m) {
            _this.sessionServiceManager.setEmail(m);
        });
        this.userDetailsSubscription = this.service.userType.subscribe(function (m) {
            _this.sessionServiceManager.setUserType(m);
        });
        this.userDetailsSubscription = this.service.vendorType.subscribe(function (m) {
            _this.sessionServiceManager.setVendorType(m);
        });
    };
    ;
    NavComponent = __decorate([
        core_1.Component({
            selector: 'app-nav',
            template: __webpack_require__(/*! ./nav.component.html */ "./src/app/nav/nav.component.html"),
            styles: [__webpack_require__(/*! ./nav.component.css */ "./src/app/nav/nav.component.css")]
        }),
        __metadata("design:paramtypes", [router_1.Router,
            session_manager_service_1.SessionManagerService, service_service_1.ServiceService])
    ], NavComponent);
    return NavComponent;
}());
exports.NavComponent = NavComponent;


/***/ }),

/***/ "./src/app/pay/pay.component.css":
/*!***************************************!*\
  !*** ./src/app/pay/pay.component.css ***!
  \***************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = ".div > div> div> div> div > qr-code > ngx-qrcode > div > img {\n    width: 200px !important;\n}\n\n"

/***/ }),

/***/ "./src/app/pay/pay.component.html":
/*!****************************************!*\
  !*** ./src/app/pay/pay.component.html ***!
  \****************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<div class=\"container\" style=\" height: 100%; min-height:800px\">\n  <div class=\"row\">\n    <div class=\"col1 offset-4\">\n      <div class=\"card card-primary card-inverse\" style=\"margin-top:8%\">\n        <div class=\"card-header\" style=\"color: #fff;background-color: #094162;border-color: #2e6da4;\">\n          <h5 align=\"center\">Check In/Check Out</h5>\n        </div>\n        <div class=\"card-body\">\n          <div class=\"row justify-content-center\">\n            <small class=\"\" style=\"color:#607D8B;\">My QR Code</small>\n          </div>\n          <div class=\"row justify-content-center\">\n            <qr-code [data]=\"qrData\"></qr-code>\n          </div>\n          <div class=\"row justify-content-center\">\n            <small style=\"color:#607D8B; text-align: center; padding: 0 10px\">Please scan this at vendor scanner to\n              check-in/check-out\n            </small>\n          </div>\n        </div>\n      </div>\n    </div>\n  </div>\n</div>\n"

/***/ }),

/***/ "./src/app/pay/pay.component.ts":
/*!**************************************!*\
  !*** ./src/app/pay/pay.component.ts ***!
  \**************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
var core_1 = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
var window_ref_service_1 = __webpack_require__(/*! ../WindowRef/window-ref.service */ "./src/app/WindowRef/window-ref.service.ts");
var wallet_service_1 = __webpack_require__(/*! ../wallet/wallet.service */ "./src/app/wallet/wallet.service.ts");
var session_manager_service_1 = __webpack_require__(/*! ../SessionManager/session-manager.service */ "./src/app/SessionManager/session-manager.service.ts");
var common_1 = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm5/common.js");
var router_1 = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
var PayComponent = /** @class */ (function () {
    function PayComponent(windowRefService, walletService, route, sessionServiceManager, location) {
        this.windowRefService = windowRefService;
        this.walletService = walletService;
        this.route = route;
        this.sessionServiceManager = sessionServiceManager;
        this.location = location;
        this.options = {
            "key": "rzp_test_BPh9OrHFTRwPqt",
            "amount": "0",
            "name": "MoveHack"
        };
    }
    PayComponent.prototype.initPay = function (amt) {
        var _this = this;
        amt = parseFloat(amt) * 100;
        this.options.handler = (function (response) {
            _this.paymentReq = {
                "paymentId": response.razorpay_payment_id,
                "amount": amt,
                "aadhaarNo": _this.aadhaarNo
            };
            _this.walletService.capturePayment(_this.paymentReq)
                .then(function (res) {
                if (res.result == 200) {
                    location.reload();
                    //TODO: Show in UI
                    alert("Amount Added successfully!");
                }
            });
        });
        this.options.amount = amt;
        this.rzp1 = new this.windowRefService.nativeWindow.Razorpay(this.options);
        this.rzp1.open();
    };
    PayComponent.prototype.ngOnInit = function () {
        if (this.sessionServiceManager.getUserSessionToken() === null || this.sessionServiceManager.getUserSessionToken() === undefined) {
            this.route.navigateByUrl('/login');
        }
        this.amount = "0.00";
        this.aadhaarNo = this.sessionServiceManager.getAadhaar();
        this.qrData = this.aadhaarNo;
    };
    PayComponent = __decorate([
        core_1.Component({
            selector: 'app-pay',
            template: __webpack_require__(/*! ./pay.component.html */ "./src/app/pay/pay.component.html"),
            styles: [__webpack_require__(/*! ./pay.component.css */ "./src/app/pay/pay.component.css")]
        }),
        __metadata("design:paramtypes", [window_ref_service_1.WindowRefService,
            wallet_service_1.WalletService,
            router_1.Router,
            session_manager_service_1.SessionManagerService,
            common_1.Location])
    ], PayComponent);
    return PayComponent;
}());
exports.PayComponent = PayComponent;


/***/ }),

/***/ "./src/app/service/service.service.ts":
/*!********************************************!*\
  !*** ./src/app/service/service.service.ts ***!
  \********************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
var core_1 = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
var http_1 = __webpack_require__(/*! @angular/common/http */ "./node_modules/@angular/common/fesm5/http.js");
var app_module_1 = __webpack_require__(/*! ../app.module */ "./src/app/app.module.ts");
var rxjs_1 = __webpack_require__(/*! rxjs */ "./node_modules/rxjs/_esm5/index.js");
var ServiceService = /** @class */ (function () {
    function ServiceService(http) {
        this.http = http;
        this.firstNameSubs = new rxjs_1.BehaviorSubject("");
        this.firstName = this.firstNameSubs.asObservable();
        this.lastNameSubs = new rxjs_1.BehaviorSubject("");
        this.lastName = this.lastNameSubs.asObservable();
        this.mobileSubs = new rxjs_1.BehaviorSubject("");
        this.mobile = this.mobileSubs.asObservable();
        this.aadhaarSub = new rxjs_1.BehaviorSubject("");
        this.aadhaar = this.aadhaarSub.asObservable();
        this.emailSubs = new rxjs_1.BehaviorSubject("");
        this.email = this.emailSubs.asObservable();
        this.vendorTypSubs = new rxjs_1.BehaviorSubject("");
        this.vendorType = this.vendorTypSubs.asObservable();
        this.userTypeSubs = new rxjs_1.BehaviorSubject("");
        this.userType = this.userTypeSubs.asObservable();
        this.loggedInVar = new rxjs_1.BehaviorSubject(false);
        this.logMsg = this.loggedInVar.asObservable();
        this.baseUri = "http://ec2-13-232-98-71.ap-south-1.compute.amazonaws.com/parse/functions";
    }
    ServiceService.prototype.setUserObject = function (user) {
        console.log("User from service service", user);
        this.firstNameSubs.next(user.fname);
        this.lastNameSubs.next(user.lname);
        this.aadhaarSub.next(user.aadhaar);
        this.emailSubs.next(user.email);
        this.mobileSubs.next(user.phoneNo);
        this.userTypeSubs.next(user.userType);
        this.vendorTypSubs.next(user.vendorType);
        console.log("Called next");
    };
    ServiceService.prototype.setLoggedIn = function (value) {
        this.loggedInVar.next(value);
    };
    /*
      {
        "origin": {
            "lat": 17.4944085,
            "long": 78.3158931
        },
        "destination": {
            "lat": 17.4950245,
            "long": 78.3158706
        },
        "mode": "WALKING",
        "time": 71
    },
    */
    ServiceService.prototype.getRoute = function (originLatLong, destinationLatLong) {
        /*let travelOpts: TravelOptions[] = [];
        let route :Route[] = [];
        route.push(new Route(new LatLng(17.4175, 78.3463),new LatLng(17.2403, 78.4294), "Direct Cab Till RGIA", "CAB", 3600, 39800,600));
        
        travelOpts.push(
          new TravelOptions(
            "Best Cab Route",
            1,
            89,
            "Waverock",
            "RGIA",
            39800,
            3600,
            750,
            route
          ));
    
        route = [];
        route.push(new Route(new LatLng(17.4175, 78.3463),new LatLng(17.4354, 78.3407), "Auto Till ISB Bus Stand", "TRANSIT",  2000, 1200,50, new TransitDetail('AUTO')));
        route.push(new Route(new LatLng(17.4354, 78.3407),new LatLng(17.4401, 78.3489), "Bus 18A towards ORR Circle", "TRANSIT",  5000, 1500,20,new TransitDetail('BUS')));
        route.push(new Route(new LatLng(17.4401, 78.3489),new LatLng(17.2403, 78.4294), "PushPak BusTowards ORR", "TRANSIT", 32800, 3600,220,new TransitDetail('CAB')));
        
        travelOpts.push(
          new TravelOptions(
            "Optimized Cost Saving Option",
            2,
            78,
            "Waverock",
            "RGIA",
            39800,
            10600,
            270,
            route
          ));
    
        return Promise.resolve(travelOpts);
      
        console.log("Service", originLatLong, destinationLatLong)
        
          var obj = {
          "origin": {
                 "lat": originLatLong.lat,
                 "long": originLatLong.lng
           },
          "destination": {
                 "lat": destinationLatLong.lat,
                 "long": destinationLatLong.lng
           }
          }; */
        var obj = {
            "origin": {
                "lat": originLatLong.lat,
                "long": originLatLong.lng
            },
            "destination": {
                "lat": destinationLatLong.lat,
                "long": destinationLatLong.lng
            }
        };
        return this.http
            .post(this.baseUri + '/getRoutes', obj, app_module_1.httpOptions)
            .toPromise()
            .then(function (response) { return response.result; })
            .catch(this.handleError);
    };
    ServiceService.prototype.getTransactions = function (aadhaarNo, userType) {
        var postData = {
            "aadhaarNo": aadhaarNo,
            "userType": userType
        };
        return this.http
            .post(this.baseUri + "/getTransaction", postData, app_module_1.httpOptions)
            .toPromise()
            .then(function (response) { return response.result; })
            .catch(this.handleError);
    };
    ServiceService.prototype.swipe = function (customerAadhaar, vendorAadhaar, location, vendorType) {
        var postData = {
            "customerAadhaar": customerAadhaar,
            "vendorAadhaar": vendorAadhaar,
            "location": {
                "lat": location.coords.latitude,
                "lng": location.coords.longitude
            },
            "vendorType": vendorType
        };
        return this.http
            .post(this.baseUri + '/swipeInOrOut', postData, app_module_1.httpOptions)
            .toPromise()
            .then(function (response) { return response; })
            .catch(this.handleError);
    };
    ServiceService.prototype.handleError = function (error) {
        console.log('Error From Service: ' + error);
        return Promise.reject(error.message || error);
    };
    ServiceService = __decorate([
        core_1.Injectable({
            providedIn: 'root'
        }),
        __metadata("design:paramtypes", [http_1.HttpClient])
    ], ServiceService);
    return ServiceService;
}());
exports.ServiceService = ServiceService;


/***/ }),

/***/ "./src/app/user-transaction/UserDetails.ts":
/*!*************************************************!*\
  !*** ./src/app/user-transaction/UserDetails.ts ***!
  \*************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

Object.defineProperty(exports, "__esModule", { value: true });
var User = /** @class */ (function () {
    function User(firstName, lastName, mobile, email, aadhar, userType, vendorType) {
        this.fname = firstName;
        this.lname = lastName;
        this.phoneNo = mobile;
        this.email = email;
        this.aadhaar = aadhar;
        this.userType = userType;
        this.vendorType = vendorType;
    }
    return User;
}());
exports.User = User;


/***/ }),

/***/ "./src/app/user-transaction/user-transaction.component.css":
/*!*****************************************************************!*\
  !*** ./src/app/user-transaction/user-transaction.component.css ***!
  \*****************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = ""

/***/ }),

/***/ "./src/app/user-transaction/user-transaction.component.html":
/*!******************************************************************!*\
  !*** ./src/app/user-transaction/user-transaction.component.html ***!
  \******************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<div class=\"col-md-12 col-sm-12 col-lg-12 col-xs-12\" style=\"min-height:500px;padding: 0\">\n  <div class=\"row\">\n    <div class=\"col-md-4 col-lg-4 col-sm-12 col-xs-12\" style=\"padding: 0\">\n      <div class=\"card card-primary card-inverse\">\n        <div class=\"card-header\" style=\"color: #fff;background-color: #303F9F;\">\n          <h5>My Profile</h5>\n        </div>\n        <div class=\"card-body\">\n          <div class=\"container\">\n            <div class=\"row\">\n              <div class=\"col\">\n                <p class=\"card-text\"> <span style=\"width:20px\"><b> Aadhaar Number: </b></span>  <span>Prateek</span></p>\n                <p class=\"card-text\"> <span style=\"width:20px\"><b> First Name: </b></span>  <span>Prateek</span></p>\n                <p class=\"card-text\"> <span style=\"width:20px\"><b> Last Name: </b></span>  <span>Prateek</span></p>\n                <p class=\"card-text\"> <span style=\"width:20px\"><b> Mobile Number: </b></span>  <span>Prateek</span></p>\n                <p class=\"card-text\"> <span style=\"width:20px\"><b> Email: </b></span>  <span>Prateek</span></p>\n              </div>\n              <div class=\"col\">\n\n              </div>\n            </div>\n\n          </div>\n        </div>\n      </div>\n    </div>\n    <div class=\"col-md-8 col-lg-8 col-sm-12 col-xs-12\">\n      <div class=\"col-md-12 col-sm-12 col-lg-12 col-xs-12\"></div>\n\n      <div class=\"card card-primary card-inverse\">\n        <div class=\"card-header\" style=\"color: #fff;background-color: #303F9F;\">\n          <h5>Travel Route</h5>\n        </div>\n        <div class=\"card-body\">\n          <div class=\"container\">\n\n          </div>\n        </div>\n      </div>\n    </div>\n  </div>\n</div>\n"

/***/ }),

/***/ "./src/app/user-transaction/user-transaction.component.ts":
/*!****************************************************************!*\
  !*** ./src/app/user-transaction/user-transaction.component.ts ***!
  \****************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
var core_1 = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
var service_service_1 = __webpack_require__(/*! ../service/service.service */ "./src/app/service/service.service.ts");
var session_manager_service_1 = __webpack_require__(/*! ../SessionManager/session-manager.service */ "./src/app/SessionManager/session-manager.service.ts");
var router_1 = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
var UserTransactionComponent = /** @class */ (function () {
    function UserTransactionComponent(serviceService, sessionManageService, router) {
        var _this = this;
        this.serviceService = serviceService;
        this.sessionManageService = sessionManageService;
        this.router = router;
        var aadhaarNo = this.sessionManageService.getAadhaar();
        console.log("Adhar", aadhaarNo);
        if (undefined != aadhaarNo && aadhaarNo.length > 0) {
            this.serviceService.getTransactions(aadhaarNo, "customer").then(function (res) {
                _this.transactionDetails = res;
            });
        }
        else {
            // alert('Session not found');
            //this.router.navigateByUrl('/login');
        }
    }
    UserTransactionComponent.prototype.ngOnInit = function () {
    };
    UserTransactionComponent = __decorate([
        core_1.Component({
            selector: 'app-user-transaction',
            template: __webpack_require__(/*! ./user-transaction.component.html */ "./src/app/user-transaction/user-transaction.component.html"),
            styles: [__webpack_require__(/*! ./user-transaction.component.css */ "./src/app/user-transaction/user-transaction.component.css")]
        }),
        __metadata("design:paramtypes", [service_service_1.ServiceService, session_manager_service_1.SessionManagerService, router_1.Router])
    ], UserTransactionComponent);
    return UserTransactionComponent;
}());
exports.UserTransactionComponent = UserTransactionComponent;


/***/ }),

/***/ "./src/app/wallet/wallet.component.css":
/*!*********************************************!*\
  !*** ./src/app/wallet/wallet.component.css ***!
  \*********************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = ""

/***/ }),

/***/ "./src/app/wallet/wallet.component.html":
/*!**********************************************!*\
  !*** ./src/app/wallet/wallet.component.html ***!
  \**********************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<div class=\"col-lg-12\" style=\" height: 100%; min-height:800px\">\n  <div class=\"row\">\n    <div class=\"col-lg-3\">\n      <div class=\"container\">\n        <div class=\"row\">\n          <div class=\"card card-primary card-inverse\" style=\"width: 100%\">\n            <div class=\"card-header\" style=\"color: #fff;background-color: #303F9F;border-color: #2e6da4;\">\n              <h5 align=\"center\">Wallet</h5>\n            </div>\n            <div class=\"card-body\">\n              <p class=\"card-text\"> <span style=\"width:20px\"><b> Aadhaar Number: </b></span>  <span>Prateek</span></p>\n              <p class=\"card-text\"> <span style=\"width:20px\"><b> First Name: </b></span>  <span>Prateek</span></p>\n              <p class=\"card-text\"> <span style=\"width:20px\"><b> Last Name: </b></span>  <span>Prateek</span></p>\n              <p class=\"card-text\"> <span style=\"width:20px\"><b> Mobile Number: </b></span>  <span>Prateek</span></p>\n              <p class=\"card-text\"> <span style=\"width:20px\"><b> Email: </b></span>  <span>Prateek</span></p>\n            </div>\n          </div>\n        </div>\n        <br>\n        <div class=\"row\">\n          <div class=\"card card-primary card-inverse\" style=\"width: 100%\">\n            <div class=\"card-header\" style=\"color: #fff;background-color: #303F9F;border-color: #2e6da4;\">\n              <h5 align=\"center\">Wallet</h5>\n            </div>\n            <div class=\"card-body\">\n              <div class=\"justify-content-center\">\n                <small style=\"color:#607D8B;\">My QR Code</small>\n                <qr-code [data]=\"qrData\"></qr-code>\n              </div>\n              <div style=\"margin-top:15px\">\n                <h3>Wallet Balance : <span style=\"color: green\">₹ {{ walletBalance }}</span></h3>\n              </div>\n              <br>\n              <div class=\"form\">\n                <div class=\"input-group\" style=\"margin-top:10px; margin-bottom:10px\">\n                  <div class=\"input-group-prepend\">\n                  <span class=\"input-group-text\"\n                        id=\"inputGroupPrepend\">&nbsp;&nbsp;&nbsp;₹&nbsp;&nbsp;&nbsp;&nbsp;</span>\n                  </div>\n                  <input type=\"number\" class=\"form-control\" aria-describedby=\"inputGroupPrepend\" name=\"amount\"\n                         class=\"form-control\" id=\"amount\" value=\"0.00\" [(ngModel)]=\"amount\" required>\n                </div>\n                <div class=\"row justify-content-center\">\n                  <button style=\"margin-top: 20px\" type=\"submit\" class=\"btn btn-success\" (click)=\"initPay(amount)\">Add\n                    Money\n                  </button>\n                </div>\n              </div>\n            </div>\n          </div>\n        </div>\n      </div>\n    </div>\n    <div class=\"col-lg-9\">\n      <div class=\"card card-primary card-inverse\">\n        <div class=\"card-header\" style=\"color: #fff;background-color: #303F9F;border-color: #2e6da4;\">\n          <h5 align=\"center\">Recent Transactions</h5>\n        </div>\n        <div class=\"card-body\">\n          <table class=\"table table-hover\">\n            <thead>\n            <tr align=\"center\">\n              <th scope=\"col\">Date</th>\n              <th scope=\"col\">Fare(₹)</th>\n              <th scope=\"col\">Distance(Kms)</th>\n              <th scope=\"col\">Time(mins)</th>\n              <th scope=\"col\">Mode</th>\n            </tr>\n            </thead>\n            <tbody>\n            <tr align=\"center\">\n              <th scope=\"row\">2018-08-28T00:06:27.422Z</th>\n              <td>120</td>\n              <td>23</td>\n              <td>30</td>\n              <td>UberGo</td>\n            </tr>\n            </tbody>\n          </table>\n        </div>\n      </div>\n    </div>\n  </div>\n</div>\n\n"

/***/ }),

/***/ "./src/app/wallet/wallet.component.ts":
/*!********************************************!*\
  !*** ./src/app/wallet/wallet.component.ts ***!
  \********************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
var core_1 = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
var window_ref_service_1 = __webpack_require__(/*! ../WindowRef/window-ref.service */ "./src/app/WindowRef/window-ref.service.ts");
var wallet_service_1 = __webpack_require__(/*! ./wallet.service */ "./src/app/wallet/wallet.service.ts");
var session_manager_service_1 = __webpack_require__(/*! ../SessionManager/session-manager.service */ "./src/app/SessionManager/session-manager.service.ts");
var common_1 = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm5/common.js");
var router_1 = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
var service_service_1 = __webpack_require__(/*! ../service/service.service */ "./src/app/service/service.service.ts");
var WalletComponent = /** @class */ (function () {
    function WalletComponent(windowRefService, walletService, sessionServiceManager, location, service, router) {
        var _this = this;
        this.windowRefService = windowRefService;
        this.walletService = walletService;
        this.sessionServiceManager = sessionServiceManager;
        this.location = location;
        this.service = service;
        this.router = router;
        this.options = {
            "key": "rzp_test_BPh9OrHFTRwPqt",
            "amount": "0",
            "name": "MoveHack"
        };
        this.aadhaarNo = this.sessionServiceManager.getAadhaar();
        this.transactionDetails = [];
        this.service.getTransactions(this.aadhaarNo, "customer").then(function (res) {
            _this.transactionDetails = res;
            console.log(_this.transactionDetails);
        });
    }
    WalletComponent.prototype.initPay = function (amt) {
        var _this = this;
        amt = parseFloat(amt) * 100;
        this.options.handler = (function (response) {
            _this.paymentReq = {
                "paymentId": response.razorpay_payment_id,
                "amount": amt,
                "aadhaarNo": _this.aadhaarNo
            };
            _this.walletService.capturePayment(_this.paymentReq)
                .then(function (res) {
                if (res.result == 200) {
                    location.reload();
                    //TODO: Show in UI
                    alert("Amount Added successfully!");
                }
            });
        });
        this.options.amount = amt;
        this.rzp1 = new this.windowRefService.nativeWindow.Razorpay(this.options);
        this.rzp1.open();
    };
    WalletComponent.prototype.getWalletBalance = function () {
        var _this = this;
        this.walletService.getWalletBalance({ "aadhaarNo": this.aadhaarNo })
            .then(function (res) {
            console.log(res.result);
            _this.walletBalance = (parseFloat(res.result) / 100).toString();
        });
    };
    WalletComponent.prototype.ngOnInit = function () {
        if (this.sessionServiceManager.getUserSessionToken() === null || this.sessionServiceManager.getUserSessionToken() === undefined) {
            this.router.navigateByUrl('/login');
        }
        this.amount = "0.00";
        this.aadhaarNo = this.sessionServiceManager.getAadhaar();
        this.getWalletBalance();
        this.qrData = this.aadhaarNo;
    };
    WalletComponent = __decorate([
        core_1.Component({
            selector: 'app-wallet',
            template: __webpack_require__(/*! ./wallet.component.html */ "./src/app/wallet/wallet.component.html"),
            styles: [__webpack_require__(/*! ./wallet.component.css */ "./src/app/wallet/wallet.component.css")]
        }),
        __metadata("design:paramtypes", [window_ref_service_1.WindowRefService,
            wallet_service_1.WalletService,
            session_manager_service_1.SessionManagerService,
            common_1.Location,
            service_service_1.ServiceService,
            router_1.Router])
    ], WalletComponent);
    return WalletComponent;
}());
exports.WalletComponent = WalletComponent;


/***/ }),

/***/ "./src/app/wallet/wallet.service.ts":
/*!******************************************!*\
  !*** ./src/app/wallet/wallet.service.ts ***!
  \******************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
var core_1 = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
var http_1 = __webpack_require__(/*! @angular/common/http */ "./node_modules/@angular/common/fesm5/http.js");
var httpOptions = {
    headers: new http_1.HttpHeaders({
        "X-Parse-Application-Id": "myAppId",
        "Content-Type": "application/json",
        "X-Parse-REST-API-Key": "myRestKey"
    })
};
var WalletService = /** @class */ (function () {
    function WalletService(http) {
        this.http = http;
    }
    WalletService.prototype.capturePayment = function (paymentReq) {
        return this.http
            .post('http://ec2-13-232-98-71.ap-south-1.compute.amazonaws.com/parse/functions/capturePayment', paymentReq, httpOptions)
            .toPromise()
            .then(function (response) { return response; })
            .catch(this.handleError);
    };
    WalletService.prototype.getWalletBalance = function (req) {
        return this.http
            .post('http://ec2-13-232-98-71.ap-south-1.compute.amazonaws.com/parse/functions/getWalletBalance', req, httpOptions)
            .toPromise()
            .then(function (response) { return response; })
            .catch(this.handleError);
    };
    WalletService.prototype.handleError = function (error) {
        console.log('Error From Service: ' + error);
        return Promise.reject(error.message || error);
    };
    WalletService = __decorate([
        core_1.Injectable({
            providedIn: 'root'
        }),
        __metadata("design:paramtypes", [http_1.HttpClient])
    ], WalletService);
    return WalletService;
}());
exports.WalletService = WalletService;


/***/ }),

/***/ "./src/environments/environment.ts":
/*!*****************************************!*\
  !*** ./src/environments/environment.ts ***!
  \*****************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

// This file can be replaced during build by using the `fileReplacements` array.
// `ng build ---prod` replaces `environment.ts` with `environment.prod.ts`.
// The list of file replacements can be found in `angular.json`.
Object.defineProperty(exports, "__esModule", { value: true });
exports.environment = {
    production: false
};
/*
 * In development mode, to ignore zone related error stack frames such as
 * `zone.run`, `zoneDelegate.invokeTask` for easier debugging, you can
 * import the following file, but please comment it out in production mode
 * because it will have performance impact when throw error
 */
// import 'zone.js/dist/zone-error';  // Included with Angular CLI.


/***/ }),

/***/ "./src/main.ts":
/*!*********************!*\
  !*** ./src/main.ts ***!
  \*********************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

Object.defineProperty(exports, "__esModule", { value: true });
var core_1 = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
var platform_browser_dynamic_1 = __webpack_require__(/*! @angular/platform-browser-dynamic */ "./node_modules/@angular/platform-browser-dynamic/fesm5/platform-browser-dynamic.js");
var app_module_1 = __webpack_require__(/*! ./app/app.module */ "./src/app/app.module.ts");
var environment_1 = __webpack_require__(/*! ./environments/environment */ "./src/environments/environment.ts");
if (environment_1.environment.production) {
    core_1.enableProdMode();
}
platform_browser_dynamic_1.platformBrowserDynamic().bootstrapModule(app_module_1.AppModule)
    .catch(function (err) { return console.log(err); });


/***/ }),

/***/ 0:
/*!***************************!*\
  !*** multi ./src/main.ts ***!
  \***************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__(/*! /Users/sumansahu/Documents/movehack/movehack/movehack-ui/Movehack/src/main.ts */"./src/main.ts");


/***/ })

},[[0,"runtime","vendor"]]]);
//# sourceMappingURL=main.js.map